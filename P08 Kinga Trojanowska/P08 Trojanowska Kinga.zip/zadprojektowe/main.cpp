#include <iostream>
#include <fstream>

using namespace std;
int rozmiar;
int max_dlugosc;
int max_index;

void funkcja(int t[],int idx) // szuka najdluzszy podciag jedynek
{
    int max_dl = 0;
    int max_idx = 0;
    int dlugosc = 0;
    int i = 0;
    while(i<rozmiar) // petla przechodzaca po elementach w tablicy
    {
        if (t[i] == 1) //jezeli wartosc elementu jest rowna 1
        {
            dlugosc++; //zwiekszamy dlugosc i "i" o 1
            i++;
            if (dlugosc > max_dl) //jezeli dlugosc jest wieksza niz maksymalna dlugosc to zostaje ona nowa maksymalna dlugoscia
            {
                max_dl = dlugosc;
            }
        }
        else //w przeciwnym razie dlugosc jest rowna 0 a "i" zwiekszamy o 1
        {
            dlugosc = 0;
            i++;
        }
    }
    if (max_dl > max_dlugosc) // sprawdza czy podciag jest najdluzszy globalnie
    {
        max_dlugosc = max_dl;
        max_index = idx;
    }

}

int main()
{
  fstream plik;
  plik.open("wynik.txt", ios::out); // Otwarcie/utworzenie pliku, do kt�rego zapisywany b�dzie wynik

  cout << "Podaj rozmiar tablicy: ";
  cin>>rozmiar; //u�ytkownik podaje rozmiar tablicy

  cout<<"Wprowadz liczbe 0 lub 1" <<endl; //komunikat, kt�ry wskazuje jakie liczby nale�y wpisa� w tablice

  int * tablica = new int[rozmiar]; //stworzenie tablicy dynamicznej

  for(int i=0; i<rozmiar; i++) //petla kt�ra pozwoli nam utworzyc tablice
  {
      int x;
      cout<<"Podaj wartosc numer " << i + 1 << ": "; //Wpisujemy, �e warto�� "i+1" poniewaz tablice rozpoczynaja sie od indeksu 0
      cin >> x;

      while((x != 0)&&(x!=1)) //jezeli x nie jest rowny 0 lub x nie jest rowny 1 postepuj zgodnie z petla
      {
        cout<<"Wprowadz liczbe 0 lub 1! " <<endl;
        cout<<"Podaj wartosc numer " << i + 1 << ": ";
        cin>>x;
      }

    tablica[i]=x; //przyporzadkuje x do indeksu tablicy

  }
    cout <<endl<< "Wyswietlamy tablice" << endl;
    for (int i=0; i<rozmiar; i++) //petla ktora pomaga wyswietlic tablice
    {
        cout << tablica[i] <<" ";
        plik << tablica[i] <<" "; //wczytywanie tablicy do pliku
    }
  for(int i=0;i<rozmiar;i++) // petla zamieniajaca 0 na 1
  {
    if (tablica[i] == 0) //jesli wartosc jest rowna 0
    {
        tablica[i] = 1; //zamien na 1
        funkcja(tablica,i); //odniesienie sie do funkcji ->postepuj zgodnie z funkcja
        tablica[i] = 0; //po czym zamien na 0
    }
  }
  cout <<endl<<"Po zastapieniu zera pod indeksem "<<max_index<<" otrzyma sie najdluzszy ciag jedynek"<<endl; //komunikat wyjscia

  plik <<"Po zastapieniu zera pod indeksem "<<max_index<<" otrzyma sie najdluzszy ciag jedynek"<<endl; //wczytywanie do pliku

  plik.close(); // zamkniecie pliku

  return 0;
  }
